package Workshop.DemoSonarqube;
import java.util.Calendar;
import java.util.Arrays;
/**
 * Hello world!
 *
 */

public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
        coletarInfo("pedro","19");
        
        
        
    }
    
    
    
    public void coletarInfo(String nome, int Idade) {
    	System.out.println("Olá "+nome+" Sua idade é: "+idade);
    }
}
